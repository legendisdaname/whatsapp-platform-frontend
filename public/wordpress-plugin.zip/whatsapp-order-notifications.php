<?php
/**
 * Plugin Name: WhatsApp Platform - Order Notifications
 * Plugin URI: https://whatsapp-platform.com
 * Description: Send automatic WhatsApp notifications for WooCommerce orders using WhatsApp Platform. Professional e-commerce messaging solution.
 * Version: 1.0.0
 * Author: WhatsApp Platform
 * Author URI: https://whatsapp-platform.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Requires at least: 5.0
 * Requires PHP: 7.2
 * WC requires at least: 3.0
 * WC tested up to: 8.0
 * Network: false
 * Text Domain: whatsapp-platform
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Check if WooCommerce is active
if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    return;
}

class WhatsApp_Platform_Order_Notifications {
    
    private $api_url;
    private $session_id;
    private $version = '1.0.0';
    private $plugin_name = 'WhatsApp Platform - Order Notifications';
    
    public function __construct() {
        $this->api_url = get_option('whatsapp_api_url', '');
        $this->session_id = get_option('whatsapp_session_id', '');
        
        // Hooks
        add_action('woocommerce_new_order', array($this, 'send_new_order_notification'), 10, 1);
        add_action('woocommerce_order_status_changed', array($this, 'send_status_change_notification'), 10, 3);
        
        // Admin
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_init', array($this, 'handle_auto_config'));
        add_action('admin_notices', array($this, 'admin_notices'));
        
        // Add settings link on plugin page
        add_filter('plugin_action_links_' . plugin_basename(__FILE__), array($this, 'add_settings_link'));
        
        // Add delayed notification hook
        add_action('whatsapp_delayed_order_notification', array($this, 'send_new_order_notification'));
        
        // REST API endpoint for auto-configuration
        add_action('rest_api_init', array($this, 'register_rest_routes'));
    }
    
    /**
     * Register REST API routes for auto-configuration
     */
    public function register_rest_routes() {
        register_rest_route('whatsapp/v1', '/configure', array(
            'methods' => 'POST',
            'callback' => array($this, 'api_configure'),
            'permission_callback' => function() {
                return current_user_can('manage_woocommerce');
            }
        ));
        
        register_rest_route('whatsapp/v1', '/status', array(
            'methods' => 'GET',
            'callback' => array($this, 'api_status'),
            'permission_callback' => '__return_true'
        ));
    }
    
    /**
     * API endpoint to configure the plugin automatically
     */
    public function api_configure($request) {
        $api_url = sanitize_url($request->get_param('api_url'));
        $session_id = sanitize_text_field($request->get_param('session_id'));
        
        if (empty($api_url) || empty($session_id)) {
            return new WP_Error('missing_params', 'API URL and Session ID are required', array('status' => 400));
        }
        
        update_option('whatsapp_api_url', $api_url);
        update_option('whatsapp_session_id', $session_id);
        update_option('whatsapp_auto_configured', true);
        
        return array(
            'success' => true,
            'message' => 'Plugin configured successfully',
            'api_url' => $api_url,
            'session_id' => $session_id
        );
    }
    
    /**
     * API endpoint to check configuration status
     */
    public function api_status($request) {
        return array(
            'configured' => !empty($this->api_url) && !empty($this->session_id),
            'api_url' => $this->api_url,
            'session_id' => $this->session_id ? substr($this->session_id, 0, 8) . '***' : '',
            'version' => $this->version
        );
    }
    
    /**
     * Handle auto-configuration from URL parameters
     */
    public function handle_auto_config() {
        if (!isset($_GET['whatsapp_auto_setup']) || !current_user_can('manage_woocommerce')) {
            return;
        }
        
        $api_url = isset($_GET['api_url']) ? sanitize_url($_GET['api_url']) : '';
        $session_id = isset($_GET['session_id']) ? sanitize_text_field($_GET['session_id']) : '';
        
        if ($api_url && $session_id) {
            update_option('whatsapp_api_url', $api_url);
            update_option('whatsapp_session_id', $session_id);
            update_option('whatsapp_auto_configured', true);
            
            wp_redirect(admin_url('admin.php?page=whatsapp-notifications&whatsapp_configured=success'));
            exit;
        }
    }
    
    /**
     * Send notification for new orders
     */
    public function send_new_order_notification($order_id) {
        try {
            // Add delay to ensure order is fully saved
            if (wp_doing_ajax()) {
                wp_schedule_single_event(time() + 5, 'whatsapp_delayed_order_notification', array($order_id));
                return;
            }
            
            $order = wc_get_order($order_id);
            
            if (!$order) {
                $this->log_error('Order not found: ' . $order_id);
                return;
            }
            
            // Skip if already processed
            $notes = $order->get_customer_order_notes();
            foreach ($notes as $note) {
                if (strpos($note->content, 'WhatsApp notification') !== false) {
                    $this->log_error('Order ' . $order_id . ' already processed');
                    return;
                }
            }
            
            $phone = $this->format_phone($order->get_billing_phone());
            
            if (!$phone) {
                $order->add_order_note('WhatsApp notification skipped: No phone number');
                $this->log_error('No phone number for order: ' . $order_id);
                return;
            }
            
            $message = $this->get_order_created_message($order);
            $result = $this->send_whatsapp_message($phone, $message);
            
            if ($result) {
                $order->add_order_note('✅ WhatsApp notification sent to: ' . $phone);
                $this->log_success('Order notification sent successfully for order: ' . $order_id . ' to: ' . $phone);
            } else {
                $order->add_order_note('❌ WhatsApp notification failed for: ' . $phone);
                $this->log_error('Failed to send WhatsApp notification for order: ' . $order_id . ' to: ' . $phone);
            }
        } catch (Exception $e) {
            $this->log_error('Order notification error: ' . $e->getMessage());
            if (isset($order)) {
                $order->add_order_note('❌ WhatsApp notification error: ' . $e->getMessage());
            }
        }
    }
    
    /**
     * Send notification for order status changes
     */
    public function send_status_change_notification($order_id, $old_status, $new_status) {
        try {
            // Only send for specific status changes
            $notify_statuses = get_option('whatsapp_notify_statuses', array('processing', 'completed', 'cancelled'));
            
            if (!in_array($new_status, $notify_statuses)) {
                $this->log_debug('Status ' . $new_status . ' not in notification list');
                return;
            }
            
            $order = wc_get_order($order_id);
            
            if (!$order) {
                $this->log_error('Order not found for status change: ' . $order_id);
                return;
            }
            
            $phone = $this->format_phone($order->get_billing_phone());
            
            if (!$phone) {
                $this->log_error('No phone number for status change notification: ' . $order_id);
                return;
            }
            
            $message = $this->get_status_change_message($order, $new_status);
            $result = $this->send_whatsapp_message($phone, $message);
            
            if ($result) {
                $order->add_order_note('✅ WhatsApp status update sent: ' . $new_status);
                $this->log_success('Status change notification sent for order: ' . $order_id . ' to: ' . $phone . ' status: ' . $new_status);
            } else {
                $order->add_order_note('❌ WhatsApp status update failed: ' . $new_status);
                $this->log_error('Failed to send status change notification for order: ' . $order_id . ' to: ' . $phone . ' status: ' . $new_status);
            }
        } catch (Exception $e) {
            $this->log_error('Status change notification error: ' . $e->getMessage());
        }
    }
    
    /**
     * Get message template for new orders
     */
    private function get_order_created_message($order) {
        $template = get_option('whatsapp_order_created_template', 
            "Hello {customer_name}! 🎉\n\n" .
            "Thank you for your order!\n\n" .
            "📦 Order #{order_number}\n" .
            "💰 Total: {currency} {total}\n\n" .
            "Items:\n{items}\n\n" .
            "We'll keep you updated!\n\n" .
            "Thank you for shopping with us! ❤️"
        );
        
        return $this->replace_placeholders($template, $order);
    }
    
    /**
     * Get message template for status changes
     */
    private function get_status_change_message($order, $status) {
        $templates = array(
            'processing' => get_option('whatsapp_processing_template', 
                "Hello {customer_name}!\n\nYour order #{order_number} is being processed! 📦\n\nWe'll notify you once it's shipped."),
            'completed' => get_option('whatsapp_completed_template', 
                "Hello {customer_name}!\n\nYour order #{order_number} is complete! 🎉\n\nThank you for your purchase!"),
            'on-hold' => get_option('whatsapp_onhold_template', 
                "Hello {customer_name}!\n\nYour order #{order_number} is on hold.\n\nPlease contact us for more information."),
            'cancelled' => get_option('whatsapp_cancelled_template', 
                "Hello {customer_name}!\n\nYour order #{order_number} has been cancelled.\n\nIf you have questions, please contact us.")
        );
        
        $template = isset($templates[$status]) ? 
            $templates[$status] : 
            "Hello {customer_name}!\n\nYour order #{order_number} status: {status}";
        
        return $this->replace_placeholders($template, $order, $status);
    }
    
    /**
     * Replace template placeholders
     */
    private function replace_placeholders($template, $order, $status = '') {
        $replacements = array(
            '{customer_name}' => $order->get_billing_first_name(),
            '{customer_full_name}' => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
            '{order_number}' => $order->get_order_number(),
            '{order_id}' => $order->get_id(),
            '{total}' => $order->get_total(),
            '{currency}' => $order->get_currency(),
            '{status}' => $status ?: $order->get_status(),
            '{order_date}' => $order->get_date_created()->format('Y-m-d H:i:s'),
            '{payment_method}' => $order->get_payment_method_title(),
            '{items}' => $this->get_order_items($order),
            '{items_count}' => $order->get_item_count(),
            '{store_name}' => get_bloginfo('name'),
            '{store_url}' => get_site_url()
        );
        
        return str_replace(
            array_keys($replacements),
            array_values($replacements),
            $template
        );
    }
    
    /**
     * Get order items as text
     */
    private function get_order_items($order) {
        $items = array();
        foreach ($order->get_items() as $item) {
            $items[] = '- ' . $item->get_name() . ' x' . $item->get_quantity();
        }
        return implode("\n", $items);
    }
    
    /**
     * Format phone number
     */
    private function format_phone($phone) {
        if (empty($phone)) {
            return '';
        }
        
        // Remove all non-numeric characters
        $phone = preg_replace('/[^0-9]/', '', $phone);
        
        // If phone starts with 0, replace with country code (assume +1 for US)
        if (strlen($phone) > 0 && $phone[0] === '0') {
            $phone = '1' . substr($phone, 1);
        }
        
        // If phone doesn't start with country code, add +1 (US)
        if (strlen($phone) === 10) {
            $phone = '1' . $phone;
        }
        
        return $phone;
    }
    
    /**
     * Send WhatsApp message via API
     */
    private function send_whatsapp_message($phone, $message) {
        if (empty($this->api_url) || empty($this->session_id)) {
            $this->log_error('API URL or Session ID not configured');
            return false;
        }
        
        $endpoint = trailingslashit($this->api_url) . 'api/messages/send';
        
        $this->log_debug('Sending WhatsApp message to: ' . $phone . ' via: ' . $endpoint);
        
        $request_data = array(
            'sessionId' => $this->session_id,
            'to' => $phone,
            'message' => $message
        );
        
        $response = wp_remote_post($endpoint, array(
            'headers' => array(
                'Content-Type' => 'application/json',
                'User-Agent' => 'WhatsApp-Platform-Order-Notifications/1.0.0 (WordPress)'
            ),
            'body' => json_encode($request_data),
            'timeout' => 30,
            'sslverify' => true,
            'blocking' => true
        ));
        
        if (is_wp_error($response)) {
            $this->log_error('API Error: ' . $response->get_error_message());
            return false;
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        
        $this->log_debug('API Response Code: ' . $response_code);
        $this->log_debug('API Response Body: ' . $response_body);
        
        if ($response_code !== 200) {
            $this->log_error('API returned non-200 status: ' . $response_code . ' - ' . $response_body);
            return false;
        }
        
        $body = json_decode($response_body, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            $this->log_error('Invalid JSON response: ' . json_last_error_msg());
            return false;
        }
        
        if (isset($body['success']) && $body['success']) {
            $this->log_success('Message sent successfully to: ' . $phone);
            return true;
        } else {
            $error_msg = isset($body['message']) ? $body['message'] : 'Unknown error';
            $this->log_error('API returned error: ' . $error_msg);
            return false;
        }
    }
    
    /**
     * Log errors
     */
    private function log_error($message) {
        error_log('WhatsApp Notifications ERROR: ' . $message);
    }
    
    /**
     * Log success messages
     */
    private function log_success($message) {
        error_log('WhatsApp Notifications SUCCESS: ' . $message);
    }
    
    /**
     * Log debug messages
     */
    private function log_debug($message) {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('WhatsApp Notifications DEBUG: ' . $message);
        }
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_submenu_page(
            'woocommerce',
            'WhatsApp Platform - Order Notifications',
            'WhatsApp Platform',
            'manage_woocommerce',
            'whatsapp-platform-notifications',
            array($this, 'settings_page')
        );
    }
    
    /**
     * Register settings
     */
    public function register_settings() {
        // General settings
        register_setting('whatsapp_platform_notifications', 'whatsapp_api_url');
        register_setting('whatsapp_platform_notifications', 'whatsapp_session_id');
        register_setting('whatsapp_platform_notifications', 'whatsapp_notify_statuses');
        
        // Templates
        register_setting('whatsapp_platform_notifications', 'whatsapp_order_created_template');
        register_setting('whatsapp_platform_notifications', 'whatsapp_processing_template');
        register_setting('whatsapp_platform_notifications', 'whatsapp_completed_template');
        register_setting('whatsapp_platform_notifications', 'whatsapp_onhold_template');
        register_setting('whatsapp_platform_notifications', 'whatsapp_cancelled_template');
    }
    
    /**
     * Settings page
     */
    public function settings_page() {
        ?>
        <div class="wrap">
            <h1>
                <span class="dashicons dashicons-whatsapp" style="font-size: 32px; color: #25D366;"></span>
                WhatsApp Platform - Order Notifications
            </h1>
            <p class="description">Professional WhatsApp messaging for your WooCommerce store powered by WhatsApp Platform</p>
            
            <?php if (empty($this->api_url) || empty($this->session_id)): ?>
            <div class="notice notice-warning">
                <p><strong>⚠️ Configuration Required:</strong> Please configure your API URL and Session ID below.</p>
            </div>
            <?php endif; ?>
            
            <form method="post" action="options.php">
                <?php settings_fields('whatsapp_platform_notifications'); ?>
                
                <div class="card">
                    <h2>🔌 API Configuration</h2>
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="whatsapp_api_url">API URL *</label>
                            </th>
                            <td>
                                <input type="url" id="whatsapp_api_url" name="whatsapp_api_url" 
                                       value="<?php echo esc_attr($this->api_url); ?>" 
                                       class="regular-text" 
                                       placeholder="https://your-api.com" 
                                       required />
                                <p class="description">Your WhatsApp Platform API URL (without trailing slash)<br><small>Get this from your WhatsApp Platform dashboard</small></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="whatsapp_session_id">Session ID *</label>
                            </th>
                            <td>
                                <input type="text" id="whatsapp_session_id" name="whatsapp_session_id" 
                                       value="<?php echo esc_attr($this->session_id); ?>" 
                                       class="regular-text" 
                                       required />
                                <p class="description">Your WhatsApp session ID from WhatsApp Platform<br><small>Find this in your WhatsApp Platform dashboard under Sessions</small></p>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <div class="card">
                    <h2>📢 Notification Settings</h2>
                    <table class="form-table">
                        <tr>
                            <th scope="row">Send notifications for:</th>
                            <td>
                                <?php
                                $notify_statuses = get_option('whatsapp_notify_statuses', array('processing', 'completed', 'cancelled'));
                                $statuses = array(
                                    'processing' => 'Processing',
                                    'completed' => 'Completed',
                                    'on-hold' => 'On Hold',
                                    'cancelled' => 'Cancelled',
                                    'refunded' => 'Refunded',
                                    'failed' => 'Failed'
                                );
                                foreach ($statuses as $key => $label): ?>
                                    <label style="display: block; margin-bottom: 5px;">
                                        <input type="checkbox" name="whatsapp_notify_statuses[]" value="<?php echo $key; ?>"
                                               <?php checked(in_array($key, $notify_statuses)); ?> />
                                        <?php echo $label; ?>
                                    </label>
                                <?php endforeach; ?>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <div class="card">
                    <h2>📝 Message Templates</h2>
                    <p>Available placeholders: <code>{customer_name}</code>, <code>{order_number}</code>, <code>{total}</code>, <code>{currency}</code>, <code>{status}</code>, <code>{items}</code>, <code>{store_name}</code></p>
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row">New Order Template</th>
                            <td>
                                <textarea name="whatsapp_order_created_template" rows="8" class="large-text code"><?php 
                                    echo esc_textarea(get_option('whatsapp_order_created_template', 
                                        "Hello {customer_name}! 🎉\n\nThank you for your order!\n\n📦 Order #{order_number}\n💰 Total: {currency} {total}\n\nItems:\n{items}\n\nWe'll keep you updated!\n\nThank you for shopping with us! ❤️")); 
                                ?></textarea>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Processing Template</th>
                            <td>
                                <textarea name="whatsapp_processing_template" rows="6" class="large-text code"><?php 
                                    echo esc_textarea(get_option('whatsapp_processing_template', 
                                        "Hello {customer_name}!\n\nYour order #{order_number} is being processed! 📦\n\nWe'll notify you once it's shipped.")); 
                                ?></textarea>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Completed Template</th>
                            <td>
                                <textarea name="whatsapp_completed_template" rows="6" class="large-text code"><?php 
                                    echo esc_textarea(get_option('whatsapp_completed_template', 
                                        "Hello {customer_name}!\n\nYour order #{order_number} is complete! 🎉\n\nThank you for your purchase!")); 
                                ?></textarea>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <?php submit_button('Save Settings', 'primary large'); ?>
            </form>
            
            <div class="card">
                <h2>🧪 Test Integration</h2>
                <p>Send a test message to verify your WhatsApp Platform configuration.</p>
                <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
                    <input type="hidden" name="action" value="whatsapp_platform_send_test" />
                    <?php wp_nonce_field('whatsapp_platform_test'); ?>
                    <input type="tel" name="test_phone" placeholder="Phone number (with country code)" class="regular-text" required />
                    <input type="submit" value="Send Test Message" class="button button-secondary" />
                </form>
            </div>
            
            <div class="card">
                <h2>📚 About WhatsApp Platform</h2>
                <p>WhatsApp Platform is a professional messaging solution that enables businesses to send WhatsApp messages at scale. This plugin integrates your WooCommerce store with WhatsApp Platform to automatically notify customers about their orders.</p>
                <p><strong>Features:</strong></p>
                <ul>
                    <li>✅ Automatic order notifications</li>
                    <li>✅ Status change alerts</li>
                    <li>✅ Customizable message templates</li>
                    <li>✅ Professional WhatsApp messaging</li>
                    <li>✅ Easy setup and configuration</li>
                </ul>
                <p><a href="https://whatsapp-platform.com" target="_blank" class="button button-primary">Learn More About WhatsApp Platform</a></p>
            </div>
        </div>
        
        <style>
            .card { 
                background: #fff; 
                border: 1px solid #ccd0d4; 
                padding: 20px; 
                margin: 20px 0; 
                box-shadow: 0 1px 1px rgba(0,0,0,.04); 
                border-radius: 4px;
            }
            .card h2 { 
                margin-top: 0; 
                color: #25D366;
                border-bottom: 2px solid #25D366;
                padding-bottom: 10px;
            }
            .wrap h1 {
                color: #25D366;
            }
            .button-primary {
                background: #25D366 !important;
                border-color: #25D366 !important;
            }
            .button-primary:hover {
                background: #128C7E !important;
                border-color: #128C7E !important;
            }
        </style>
        <?php
    }
    
    /**
     * Admin notices
     */
    public function admin_notices() {
        if (isset($_GET['whatsapp_platform_configured']) && $_GET['whatsapp_platform_configured'] === 'success') {
            echo '<div class="notice notice-success is-dismissible"><p>✅ WhatsApp Platform connected successfully! Your store is ready to send notifications.</p></div>';
        }
        
        if (isset($_GET['whatsapp_platform_test']) && $_GET['whatsapp_platform_test'] === 'success') {
            echo '<div class="notice notice-success is-dismissible"><p>✅ Test message sent successfully via WhatsApp Platform!</p></div>';
        } elseif (isset($_GET['whatsapp_platform_test']) && $_GET['whatsapp_platform_test'] === 'error') {
            echo '<div class="notice notice-error is-dismissible"><p>❌ Failed to send test message. Please check your WhatsApp Platform settings.</p></div>';
        }
        
        if (empty($this->api_url) || empty($this->session_id)) {
            $setup_url = admin_url('admin.php?page=whatsapp-platform-notifications');
            echo '<div class="notice notice-warning"><p><strong>WhatsApp Platform:</strong> Please <a href="' . $setup_url . '">configure your settings</a> to start sending notifications.</p></div>';
        }
    }
    
    /**
     * Add settings link on plugins page
     */
    public function add_settings_link($links) {
        $settings_link = '<a href="admin.php?page=whatsapp-platform-notifications">Settings</a>';
        array_unshift($links, $settings_link);
        return $links;
    }
}

// Initialize plugin
new WhatsApp_Platform_Order_Notifications();

// Handle test message
add_action('admin_post_whatsapp_platform_send_test', function() {
    check_admin_referer('whatsapp_platform_test');
    
    $phone = preg_replace('/[^0-9]/', '', $_POST['test_phone']);
    $api_url = get_option('whatsapp_api_url');
    $session_id = get_option('whatsapp_session_id');
    
    if (empty($api_url) || empty($session_id)) {
        wp_redirect(admin_url('admin.php?page=whatsapp-platform-notifications&whatsapp_platform_test=error&error=config'));
        exit;
    }
    
    // Format phone number
    if (strlen($phone) === 10) {
        $phone = '1' . $phone;
    }
    
    $response = wp_remote_post(trailingslashit($api_url) . 'api/messages/send', array(
        'headers' => array(
            'Content-Type' => 'application/json',
            'User-Agent' => 'WhatsApp-Platform-Order-Notifications/1.0.0 (WordPress)'
        ),
        'body' => json_encode(array(
            'sessionId' => $session_id,
            'to' => $phone,
            'message' => "🧪 Test message from WhatsApp Platform!\n\nYour WooCommerce store is now connected to WhatsApp Platform! ✅\n\nTime: " . current_time('mysql') . "\n\nThis message was sent via WhatsApp Platform - Order Notifications plugin."
        )),
        'timeout' => 30,
        'sslverify' => true
    ));
    
    if (is_wp_error($response)) {
        error_log('WhatsApp Platform Test Error: ' . $response->get_error_message());
        wp_redirect(admin_url('admin.php?page=whatsapp-platform-notifications&whatsapp_platform_test=error&error=' . urlencode($response->get_error_message())));
    } else {
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        
        if ($response_code === 200) {
            $body = json_decode($response_body, true);
            if (isset($body['success']) && $body['success']) {
                wp_redirect(admin_url('admin.php?page=whatsapp-platform-notifications&whatsapp_platform_test=success'));
            } else {
                wp_redirect(admin_url('admin.php?page=whatsapp-platform-notifications&whatsapp_platform_test=error&error=' . urlencode($response_body)));
            }
        } else {
            wp_redirect(admin_url('admin.php?page=whatsapp-platform-notifications&whatsapp_platform_test=error&error=' . urlencode('HTTP ' . $response_code . ': ' . $response_body)));
        }
    }
    exit;
});

